struct childrenArray
{
    int len;
    int children[64];

};

//int changeSchedulePolicy(int policy){
 //   schedulePolicy = policy
//}
