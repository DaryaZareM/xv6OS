struct timeElem
{
    int creationTime;
    int ExitTime;
    int runningTime;
    int readyTime;
    int waitTime;
};